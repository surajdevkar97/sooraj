package capgemini.labbook;
import java.util.Arrays;
import java.util.Scanner;
public class Lab3_Ex2_UpperCase {
	
public static void main(String[] args) {

	Scanner sc=new Scanner(System.in);
	
	String [] arr=new String[20];
	System.out.println("Enter your string length");
	int n=sc.nextInt();
	System.out.println("Enter your String");
	for(int i=0;i<n;i++)
	{
		arr[i]=sc.next();
		
	}
	Arrays.sort(arr);
	if(n%2==0)
	{
		for
		
	}
}
}
