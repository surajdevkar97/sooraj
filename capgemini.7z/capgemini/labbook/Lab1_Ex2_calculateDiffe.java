package capgemini.labbook;

import java.util.Scanner;

public class Lab1_Ex2_calculateDiffe {

	public static int calculateDifference(int n) {
		int sum1=0, sum2 = 0;
		for (int i = 1; i <= n; i++) {
			sum1+= (i * i);		}
		for (int i = 1; i <= n; i++) {
			sum2+=i;
		}
		sum2=sum2*sum2;
		int result=sum1-sum2;
		return result;
	}

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int result=calculateDifference(num);
		System.out.println(result);
	}
}
