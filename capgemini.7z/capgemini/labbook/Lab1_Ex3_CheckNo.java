package capgemini.labbook;

import java.util.Scanner;

public class Lab1_Ex3_CheckNo {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int i = 0, num1 = 0, num3, n, m, flag = 0;
		num1 = num;
		while (num > 0) {
			num = num / 10;
			i++;
		}
		int j = 0;
		j = i;
		while (i > 1) {
			// num1=num/10;
			m = num1 % 10;
			n = num1 % 100;
			if (n <= m) {
				flag++;
			}

			i--;
			num1 = num1 / 10;

			// System.out.println(num);
		}
		if (flag == j)
			System.out.println("True");
		else
			System.out.println("False");
	}
}
