package capgemini.labbook;

import java.util.Scanner;

public class Lab_Ex1_CalculateSum {

	public static int Calculatesum(int n) {
		int Sum = 0;
		for (int i = 1; i <= n; i++) {
			if (i % 3 == 0 || i % 5 == 0) {
				Sum = Sum + i;
			}
		}
		return (Sum);
	}

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int result = Calculatesum(num);
		System.out.println(result);
	}
}
