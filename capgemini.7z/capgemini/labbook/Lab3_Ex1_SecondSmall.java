package capgemini.labbook;

import java.util.Arrays;
import java.util.Scanner;

public class Lab3_Ex1_SecondSmall {
	public static void main(String[] args) {
		int n;
		
	
		Scanner sc = new Scanner(System.in);
		System.out.println("How many numbers you wish to enter");
		n = sc.nextInt();
		int arr[] = new int[n];
		System.out.println("Enter array elements");
		for (int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();

		}
		Arrays.sort(arr);
		System.out.println("Your second smallest element is "+arr[1]);
	}
}
