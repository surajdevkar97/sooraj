package capgemini.generics;

public class Test_generics {

}
