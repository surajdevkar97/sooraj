package capgemini.exception;

class Geeks 
{ 
	 
} 

