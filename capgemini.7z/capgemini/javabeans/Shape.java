package capgemini.javabeans;

public abstract class Shape {
	Shape()
	{
		
	}
	public abstract void draw();
	public abstract double calArea();

}
