package capgemini.javabeans;

public class circle_Test {

	public static void main(String[] args) {
		//declaration
		Rectangle r1;
		//object instantiation
		r1=new Rectangle();
		//accessing field of an object
		r1.setBreadth(5.5f);
		r1.setLength(6.5f);
		//accessing method of an object
		//r1.showRadious();
		
	}
	
}
