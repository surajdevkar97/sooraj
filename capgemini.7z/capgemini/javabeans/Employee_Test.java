package capgemini.javabeans;

public class Employee_Test {
	public static void main(String[] args) {
		Employee e1,e2;
		e1=new Employee(101,"suraj");
		e2=new Employee(102,"Toshu");
		System.out.println(e1.countr());
	}

}
