package capgemini.collection;

import java.util.HashMap;
import java.util.Iterator;

public class _HashMap {
public static void main(String[] args) {
	HashMap<Integer, String> hashMap=new HashMap<Integer,String>();
	hashMap.put(1, "Jan");
	hashMap.put(2,"Feb");
	hashMap.put(3,"Mar");
	hashMap.put(null,null);// allows only one null value
	hashMap.put(null,null);// allows only one null key
	hashMap.put(0,null); // allows many null values
	System.out.println("Size:"+hashMap.size()+"\t"+hashMap);
	//hashMap.iterator(); do not get iterator directly
	Iterator<Integer> itrKeys=hashMap.keySet().iterator();
	System.out.println("Printing keys");
	while(itrKeys.hasNext())
	{
		System.out.println(itrKeys.next());
		
	}
	Iterator<Integer> itrValues=hashMap.keySet().iterator();
	System.out.println("Printing keys");
	while(itrKeys.hasNext())
	{
		System.out.println(itrValues.next());
		
	}
	System.out.println("Printing key:values");
	Iterator<Integer> itrKeys2=hashMap.keySet().iterator();
	System.out.println("printing keys");
	while(itrKeys2.hasNext())
	{
		Integer key=itrKeys2.next();
		System.out.println(key+":"+hashMap.get(key));
	}
}
}
