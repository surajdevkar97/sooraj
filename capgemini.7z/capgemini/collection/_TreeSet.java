package capgemini.collection;

import java.util.Iterator;
import java.util.TreeSet;

public class _TreeSet {
public static void main(String[] args) {
	TreeSet<String> treeset= new  TreeSet<String>();
	System.out.println("Size:"+treeset.size()+"\t"+treeset);
	//treeset.add(null)    // null is not allowed'
	treeset.add("A");
	treeset.add("A");  //duplicate value is not allowed
	treeset.add("B"); // insertion order is not  maintained..
	//sorts value on insertion
	treeset.add("C");
	System.out.println("Size:"+treeset.size()+"\t"+treeset);
	Iterator<String> iterator=treeset.iterator();
	System.out.println("Priting in ascending order");
	while(iterator.hasNext())
	{
		System.out.println(iterator.next());
	}
	System.out.println("printing in descending order");
	Iterator<String> descendingIterator=treeset.descendingIterator();
	while(descendingIterator.hasNext())
	{
		System.out.println(descendingIterator.next());
	}
}
}
